if True:
    if False:
        print("hello")
    elif True:
        if False:
            print("world")
        else:
            print("hello world")